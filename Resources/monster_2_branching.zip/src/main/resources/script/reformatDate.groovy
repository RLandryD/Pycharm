import com.sap.gateway.ip.core.customdev.util.Message
import java.text.SimpleDateFormat

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String
    def inFmt  = new SimpleDateFormat('yyyy-MM-dd')
    def outFmt = new SimpleDateFormat('dd.MM.yyyy')
    body = body.replaceAll(/<created>(\d{4}-\d{2}-\d{2})<\/created>/) { all, d ->
        '<created>' + outFmt.format(inFmt.parse(d)) + '</created>'
    }
    message.setProperty('DatesReformatted', 'true')
    def messageLog = messageLogFactory.getMessageLog(message)
    if (messageLog != null) messageLog.setStringProperty('ScriptStep', 'executed')
    message.setBody(body)
    return message
}
