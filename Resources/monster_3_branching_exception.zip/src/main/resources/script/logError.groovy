import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def ex = message.getProperty('CamelExceptionCaught')
    def messageLog = messageLogFactory.getMessageLog(message)
    if (messageLog != null) messageLog.setStringProperty('ErrorHandled', ex as String)
    message.setProperty('ErrorHandled', 'true')
    return message
}
