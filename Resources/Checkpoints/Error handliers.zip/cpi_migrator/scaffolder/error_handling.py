"""scaffolder/error_handling.py — gold-standard exception subprocess injection.

Decoded from SAP's own published reference, the *Integration Flow Design
Guidelines — Handle Errors Gracefully* package (reviewed 2026-06-10 alongside
QforIT Error Alerting and the SAP Alert Notification service integrations).
The Guidelines establish three canonical exception-subprocess shapes:

  error_end       Error Start → Script (enrich MPL) → **Error End**
                  MPL stays FAILED; the sender still receives the error.
                  The Guidelines' baseline — honest status + full context.
  escalation_end  Error Start → Script → **Escalation End**
                  MPL status ESCALATED (visible triage queue in Monitor).
  message_end     Error Start → Script → Content Modifier (error body,
                  SAP_MessageProcessingLogCustomStatus, CamelHttpResponseCode)
                  → **Message End** — "do not throw error on failure": sync
                  callers get a crafted error response, MPL COMPLETED with a
                  custom status.

All event/step ifl:property sets here are VERBATIM from the Guidelines
bundles (ErrorEndEvent / EscalationEndEvent[ErrorCode=Others] /
ErrorStartEvent / Enricher 1.6). The capture script generalizes the
Guidelines' demo scripts to production grade: exception class+message+bounded
stack trace, MPL ID, secret-redacted headers, property names, failed payload
attachment, and an MPL custom status — everything the side-car monitors
(Alert Notification service flow) key on later.

The injector NEVER touches flows that already carry an exception subprocess
(fidelity first); it only extends flows that have none.
"""
from __future__ import annotations

def gold_capture_script(variant: str = "error_end") -> str:
    """Variant-aware capture: the custom status PREFIX names the policy the
    flow applies (Failed_/Escalated_/Handled_ + exception class), so Monitor
    triage can tell at a glance which handling each failed message got —
    user feedback: identical scripts made Error End and Escalation End look
    functionally identical even though the END EVENT drives the MPL status
    (FAILED vs ESCALATED) and sender behavior."""
    prefix = {"error_end": "Failed_", "escalation_end": "Escalated_",
              "message_end": "Handled_"}.get(variant, "Failed_")
    policy = {"error_end": "Error End (MPL FAILED, sender notified)",
              "escalation_end": "Escalation End (MPL ESCALATED)",
              "message_end":
                  "Message End (MPL COMPLETED, crafted error response)",
              }.get(variant, "Error End")
    return (GOLD_CAPTURE_SCRIPT
            .replace("'Failed_' +", f"'{prefix}' +")
            .replace("HANDLING_POLICY", policy))


GOLD_CAPTURE_SCRIPT = r"""import com.sap.gateway.ip.core.customdev.util.Message

/* Gold-standard error capture (pattern: SAP Integration Flow Design
   Guidelines - Handle Errors Gracefully). Attaches full error context to the
   MPL and sets a custom status so monitoring flows and the Monitor UI can
   triage without opening traces. */
def Message processData(Message message) {
    def log = messageLogFactory.getMessageLog(message)
    def ex = message.getProperty('CamelExceptionCaught')
    def mplId = message.getProperty('SAP_MessageProcessingLogID') ?: 'n/a'

    def sb = new StringBuilder()
    sb.append('Handling policy: HANDLING_POLICY\n')
    sb.append('MPL ID: ').append(mplId).append('\n')
    if (ex != null) {
        sb.append('Exception class: ')
          .append(ex.getClass().getCanonicalName()).append('\n')
        sb.append('Exception message: ')
          .append(ex.getMessage() ?: '').append('\n')
        def st = ex.getStackTrace()
        if (st != null && st.length > 0) {
            int n = Math.min(st.length, 15)
            sb.append('Stack trace (first ').append(n).append('):\n')
            for (int i = 0; i < n; i++) {
                sb.append('  at ').append(st[i].toString()).append('\n')
            }
        }
    } else {
        sb.append('No CamelExceptionCaught present.\n')
    }
    sb.append('Headers at failure (secrets redacted):\n')
    message.getHeaders().each { k, v ->
        if (!(k ==~ /(?i).*(auth|password|token|secret|cookie|apikey).*/)) {
            sb.append('  ').append(k).append(' = ')
              .append(String.valueOf(v).take(200)).append('\n')
        }
    }
    sb.append('Exchange property names:\n')
    message.getProperties().keySet().sort().each { k ->
        sb.append('  ').append(k).append('\n')
    }

    if (log != null) {
        log.addAttachmentAsString('ErrorContext', sb.toString(), 'text/plain')
        def body = ''
        try { body = (message.getBody(java.lang.String) ?: '') }
        catch (Exception ignore) { }
        if (body) {
            log.addAttachmentAsString('FailedPayload',
                body.take(100000), 'text/plain')
        }
        log.setStringProperty('ErrorType',
            ex != null ? ex.getClass().getSimpleName() : 'Unknown')
    }
    // visible in Monitor's Custom Status column (alphanumeric + _, max 40)
    def cs = 'Failed_' + (ex != null ? ex.getClass().getSimpleName()
                                      : 'Unknown')
    message.setProperty('SAP_MessageProcessingLogCustomStatus',
        cs.replaceAll('[^A-Za-z0-9_]', '_').take(40))
    return message
}
"""

SCRIPT_REL_PATH = "src/main/resources/script/gold_error_capture.groovy"

#: verbatim event/step configs (Design Guidelines bundles)
_ERR_START = {"activityType": "StartErrorEvent",
              "cmdVariantUri": "ctype::FlowstepVariant/cname::ErrorStartEvent"}
_ERR_END = {"activityType": "EndErrorEvent",
            "cmdVariantUri": "ctype::FlowstepVariant/cname::ErrorEndEvent"}
_ESC_END = {"ErrorCode": "Others", "componentVersion": "1.0",
            "activityType": "EscalationEndEvent",
            "cmdVariantUri":
                "ctype::FlowstepVariant/cname::EscalationEndEvent/"
                "version::1.0.0"}
_MSG_END = {"componentVersion": "1.1", "activityType": "EndEvent",
            "cmdVariantUri":
                "ctype::FlowstepVariant/cname::MessageEndEvent/version::1.1.0"}
_SUBPROC = {"componentVersion": "1.1",
            "activityType": "ErrorEventSubProcessTemplate",
            "cmdVariantUri": "ctype::FlowstepVariant/cname::"
                             "ErrorEventSubProcessTemplate/version::1.1.0"}
_GS = {"componentVersion": "1.1", "activityType": "Script",
       "cmdVariantUri":
           "ctype::FlowstepVariant/cname::GroovyScript/version::1.1.2",
       "subActivityType": "GroovyScript",
       "script": "gold_error_capture.groovy",
       "scriptFunction": "", "scriptBundleId": ""}
# message_end variant CM: Guidelines' 'Do Not Throw Error on Failure' shape,
# generalized (their wrapContent/custom status, with ${exception.message})
_CM_ERROR_RESPONSE = {
    "bodyType": "expression", "componentVersion": "1.6",
    "activityType": "Enricher",
    "cmdVariantUri": "ctype::FlowstepVariant/cname::Enricher/version::1.6.0",
    "wrapContent": "",
    "bodyContent": "<error><flow>${camelId}</flow>"
                   "<message>${exception.message}</message></error>",
    "headerTable": "<row><cell id='Action'>Create</cell>"
                   "<cell id='Type'>constant</cell><cell id='Value'>500</cell>"
                   "<cell id='Default'></cell>"
                   "<cell id='Name'>CamelHttpResponseCode</cell>"
                   "<cell id='Datatype'></cell></row>",
}

VARIANTS = ("error_end", "escalation_end", "message_end")


def has_exception_subprocess(model) -> bool:
    return any(s.kind == "ErrorEventSubProcessTemplate"
               for s in model.steps.values())


def _remove_main_exception_subprocesses(model, main) -> bool:
    """Remove every MAIN-process exception subprocess (and its transitive
    children, sequence flows, routes, message flows, and now-orphaned
    endpoint participants — 20 of 64 corpus subprocess flows wire mail
    alerts from inside the subprocess). LIP-level exception subprocesses are
    deliberately kept: they handle THAT process's errors, a different
    semantic scope. Returns True when something was removed."""
    subs = [s.id for s in model.steps.values()
            if s.kind == "ErrorEventSubProcessTemplate"
            and s.process_id == main.id and not s.parent_subprocess]
    if not subs:
        return False
    removed = set(subs)
    changed = True
    while changed:                                  # transitive children
        changed = False
        for s in model.steps.values():
            if s.id not in removed and s.parent_subprocess in removed:
                removed.add(s.id)
                changed = True
    ft = getattr(model, "_flow_target", None) or {}
    dead_fids = set()
    for sid in removed:
        st = model.steps[sid]
        dead_fids.update(st.outgoing)
        dead_fids.update(st.incoming)
    for fid in dead_fids:
        ft.pop(fid, None)
    if getattr(model, "routes", None):
        model.routes = [r for r in model.routes
                        if r.flow_id not in dead_fids]
    dead_mf = [mf for mf in model.message_flows
               if mf.source in removed or mf.target in removed]
    if dead_mf:
        keep = [mf for mf in model.message_flows if mf not in dead_mf]
        model.message_flows = keep
        live = {mf.source for mf in keep} | {mf.target for mf in keep}
        dead_parts = ({mf.source for mf in dead_mf}
                      | {mf.target for mf in dead_mf}) - removed
        model.endpoints = [e for e in model.endpoints
                           if e.id not in dead_parts or e.id in live]
    for sid in removed:
        del model.steps[sid]
    main.step_ids = [i for i in main.step_ids if i not in removed]
    if hasattr(model, "sequence") and isinstance(model.sequence, list):
        model.sequence = [i for i in model.sequence if i not in removed]
    return True


def inject_gold_error_handling(model, variant: str = "error_end",
                               replace_existing: bool = False,
                               notify_mail: bool = False) -> dict:
    """Add the gold-standard exception subprocess. Default policy: only flows
    with NO main-process exception subprocess are touched (pure fidelity for
    the rest). With replace_existing=True the client chooses the gold pattern
    OVER their current one: existing main-process exception subprocesses are
    removed first (mail-alert wiring pruned cleanly), then the chosen variant
    is injected. Returns the resource files to ship ({rel_path: content}),
    empty dict when nothing was injected."""
    from extractor.iflow_parser import Step

    if variant not in VARIANTS:
        variant = "error_end"
    main = next((p for p in model.processes if p.is_main), None)
    if main is None:
        return {}
    has_main_sub = any(
        s.kind == "ErrorEventSubProcessTemplate"
        and s.process_id == main.id and not s.parent_subprocess
        for s in model.steps.values())
    if has_main_sub:
        if not replace_existing:
            return {}
        _remove_main_exception_subprocesses(model, main)
    P = main.id
    ids = set(model.steps)
    pre = "EH_"
    while any(i.startswith(pre) for i in ids):     # collision-proof prefix
        pre += "X"

    ft = getattr(model, "_flow_target", None)
    if ft is None:
        model._flow_target = ft = {}

    def add(sid, kind, name, cfg, sub=""):
        s = Step(id=sid, kind=kind, name=name, process_id=P,
                 config=dict(cfg), parent_subprocess=sub)
        model.steps[sid] = s
        main.step_ids.append(sid)
        return s

    sub_id = pre + "SubProcess"
    add(sub_id, "ErrorEventSubProcessTemplate", "Exception Subprocess",
        _SUBPROC)
    # the parser's sequence carries top-level main-process steps only
    # (subprocess CHILDREN are excluded via parent_subprocess) — register the
    # subprocess itself so regenerate's reproduce check sees m1 == m2
    if hasattr(model, "sequence") and isinstance(model.sequence, list):
        model.sequence.append(sub_id)
    st = add(pre + "ErrorStart", "StartErrorEvent", "Error Start",
             _ERR_START, sub=sub_id)
    st.event_def = "error"
    gs = add(pre + "Capture", "Script", "GS_Gold_Error_Capture", _GS,
             sub=sub_id)
    chain = [st, gs]
    if notify_mail:
        # RCI093-decoded alert leg: CM error report → Send → Mail receiver
        # (all connection fields externalized as {{ALERT_MAIL_*}})
        from extractor.iflow_parser import Endpoint, MessageFlow
        chain.append(add(pre + "AlertBody", "Enricher", "CM_Alert_Body",
                         _CM_ALERT_BODY, sub=sub_id))
        snd = add(pre + "SendMail", "Send", "Send_Error_Mail", _SEND_STEP,
                  sub=sub_id)
        chain.append(snd)
        part_id = pre + "MailReceiver"
        model.endpoints.append(Endpoint(
            id=part_id, direction="receiver", name="ALERT_MAIL",
            etype="EndpointRecevier"))           # verbatim SAP spelling
        model.message_flows.append(MessageFlow(
            id=pre + "MailFlow", name="Mail", source=snd.id, target=part_id,
            config=dict(_MAIL_ADAPTER)))
        if hasattr(model, "parameters"):
            model.parameters.update(ALERT_MAIL_PARAMS)
    if variant == "message_end":
        chain.append(add(pre + "CM", "Enricher", "CM_Error_Response",
                         _CM_ERROR_RESPONSE, sub=sub_id))
        end = add(pre + "End", "EndEvent", "End Message", _MSG_END,
                  sub=sub_id)
        end.event_def = "message"
    elif variant == "escalation_end":
        end = add(pre + "End", "EscalationEndEvent", "Escalation End",
                  _ESC_END, sub=sub_id)
        end.event_def = "escalation"
    else:
        end = add(pre + "End", "EndErrorEvent", "Error End", _ERR_END,
                  sub=sub_id)
        end.event_def = "error"
    chain.append(end)
    for i, (a, b) in enumerate(zip(chain, chain[1:])):
        fid = f"{pre}Flow_{i}"
        a.outgoing.append(fid)
        b.incoming.append(fid)
        ft[fid] = b.id
    model._eh_notify_mail = bool(notify_mail)
    return {SCRIPT_REL_PATH: gold_capture_script(variant)}


# ── notify-by-mail leg (decoded VERBATIM from Ric's own RCI093 production
#    alert: LIP3_Exception_Alert → Set Body CM → Send → Mail adapter v1.11,
#    every connection field externalized) ──────────────────────────────────
ALERT_MAIL_PARAMS = {
    "ALERT_MAIL_SERVER": "",
    "ALERT_MAIL_FROM": "",
    "ALERT_MAIL_TO": "",
    "ALERT_MAIL_SUBJECT": "CPI Integration Error",
    "ALERT_MAIL_CRED": "",
    "ALERT_MAIL_AUTH": "None",
    "ALERT_MAIL_PROTECTION": "starttls_optional",   # RCI093's own default
    "ALERT_MAIL_PROXY": "none",
    "ALERT_MAIL_TIMEOUT": "30000",
}

_CM_ALERT_BODY = {
    "bodyType": "expression", "componentVersion": "1.6",
    "activityType": "Enricher",
    "cmdVariantUri": "ctype::FlowstepVariant/cname::Enricher/version::1.6.0",
    "wrapContent": "",
    # modeled on RCI093's 'Set Body': artifact, MPL id, exception message
    "bodyContent": "Technical error report of integration flow ${camelId}.\n"
                   "\nMessage Processing Log ID: "
                   "${property.SAP_MessageProcessingLogID}\n"
                   "Error type: ${exception.class}\n"
                   "Error message: ${exception.message}\n",
}
_SEND_STEP = {"componentVersion": "1.0", "activityType": "Send",
              "cmdVariantUri":
                  "ctype::FlowstepVariant/cname::Send/version::1.0.4"}
_MAIL_ADAPTER = {
    "ComponentNS": "com.sap.it.ide.mail.ui.namespace2",
    "ComponentSWCVId": "com.sap.it.ide.mail.ui.archive2",
    "ComponentSWCVName": "com.sap.it.ide.mail.ui.archive2",
    "ComponentType": "Mail", "Description": "",
    "MessageProtocol": "None", "MessageProtocolVersion": "1.0",
    "Name": "Mail_Alert", "TransportProtocol": "SMTP",
    "TransportProtocolVersion": "1.0",
    "attachmentTransferEncoding": "auto", "attachments": "",
    "auth": "{{ALERT_MAIL_AUTH}}", "bcc": "", "cc": "",
    "body": "${in.body}",
    "cmdVariantUri": "ctype::AdapterVariant/cname::sap:Mail/tp::SMTP/"
                     "mp::None/direction::Receiver/version::1.11.0",
    "componentVersion": "1.11", "content_encoding": "UTF-8",
    "content_type": "text/plain", "direction": "Receiver",
    "encrypt.smime.aes.gcm.keysize": "128", "encrypt.smime.aes.keysize": "128",
    "encrypt.smime.algorithm": "aes", "encrypt.smime.des.keysize": "128",
    "encrypt.smime.keys": "", "encrypt.type": "none",
    "from": "{{ALERT_MAIL_FROM}}", "keep_attachments": "0", "locationId": "",
    "proxyAlias": "", "proxyHost": "", "proxyPort": "8080",
    "proxyProtocol": "socks5", "proxyType": "{{ALERT_MAIL_PROXY}}",
    "server": "{{ALERT_MAIL_SERVER}}",
    "signature.smime.clearText": "1", "signature.smime.table": "",
    "ssl": "{{ALERT_MAIL_PROTECTION}}",
    "subject": "{{ALERT_MAIL_SUBJECT}}", "system": "ALERT_MAIL",
    "timeout": "{{ALERT_MAIL_TIMEOUT}}", "to": "{{ALERT_MAIL_TO}}",
    "tokenCredential": "", "user": "{{ALERT_MAIL_CRED}}",
}


def append_alert_params(files: dict) -> None:
    """Append the ALERT_MAIL_* externalized parameters to whatever parameter
    pair ships with the bundle (the SOURCE pair ships verbatim and wins, so
    injected params must be appended; formats verbatim from real exports)."""
    pp = "src/main/resources/parameters.prop"
    pd = "src/main/resources/parameters.propdef"
    prop = files.get(pp) or "#\n"
    pdef = files.get(pd) or ('<?xml version="1.0" encoding="UTF-8" '
                             'standalone="no"?><parameters></parameters>')
    import re as _re
    for name, default in ALERT_MAIL_PARAMS.items():
        if name not in prop:
            prop = prop.rstrip("\n") + f"\n{name}={default}\n"
        elif default:
            # the generator may have synthesized an EMPTY shell from
            # model.parameters before this runs — fill the default in
            prop = _re.sub(rf"^{name}=$", f"{name}={default}",
                           prop, count=1, flags=_re.M)
        if f"<name>{name}</name>" not in pdef:
            entry = ("<parameter>\n    <key/>\n"
                     f"    <name>{name}</name>\n"
                     "    <type>xsd:string</type>\n"
                     "    <isRequired>false</isRequired>\n"
                     "    <constraint/>\n    <description/>\n"
                     "    <additionalMetadata/>\n  </parameter>")
            pdef = pdef.replace("</parameters>", entry + "</parameters>", 1)
    files[pp] = prop
    files[pd] = pdef
