/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
    public void setProperty(java.lang.String name, java.lang.Object value)
    public java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> getSoapHeaders()
    public void setSoapHeaders(java.util.List<com.sap.gateway.ip.core.customdev.util.SoapHeader> soapHeaders) 
       public void clearSoapHeaders()
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def map = message.getProperties();
    def headers = message.getHeaders();
    def properties = message.getProperties();
    def responseCode = headers.get("CamelHttpResponseCode");
    def ex = map.get("CamelExceptionCaught");
    def requestBody = properties.get("P_Request_Body");
    
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null)
    {
        messageLog.setStringProperty("Request Body", "Printing Payload As Attachment")
        messageLog.addAttachmentAsString("Request Body", requestBody, "text/xml");
    }
    
    if( responseCode == 400 || responseCode == 401 || responseCode == 403 || responseCode == 404 || responseCode == 406 || responseCode == 500 )
    {
        return message;
    }
    if(ex!=null){
        
        if ( ex.getClass().getCanonicalName().equals("com.sap.gateway.core.ip.component.odata.exception.OsciException") || ex.getClass().getCanonicalName().equals("com.google.common.util.concurrent.UncheckedExecutionException") )
        {
            headers.put("CamelHttpResponseCode", 400 );
            message.setBody(map.get("exception"));
        }
        
        if( ex.getClass().getCanonicalName().equals("com.thoughtworks.xstream.converters.ConversionException"))
        {
            headers.put("CamelHttpResponseCode", 400 );
            message.setBody(map.get("exception"));
        }
        
        if( ex.getClass().getCanonicalName().equals("com.google.gson.stream.MalformedJsonException") ){
            headers.put("CamelHttpResponseCode", 400 );
            message.setBody( ex.getMessage() );
        }
    }
   return message;
}