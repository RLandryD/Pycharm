<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
                xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns:asx="http://www.sap.com/abapxml">

  <!-- Identity template to copy all nodes and attributes by default -->
  <xsl:template match="@*|node()">
    <xsl:copy>
      <xsl:apply-templates select="@*|node()"/>
    </xsl:copy>
  </xsl:template>

  <!-- Template to handle elements with the asx:nsd attribute -->
  <xsl:template match="*[@asx:nsd]">
    <xsl:copy>
      <!-- Copy all attributes except asx:nsd -->
      <xsl:copy-of select="@*[name() != 'asx:nsd']"/>
      <!-- Process child nodes -->
      <xsl:apply-templates/>
    </xsl:copy>
  </xsl:template>

</xsl:stylesheet>