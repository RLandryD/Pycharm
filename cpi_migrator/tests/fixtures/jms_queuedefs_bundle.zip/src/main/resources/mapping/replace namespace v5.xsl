<xsl:stylesheet version="1.0" xmlns:edoc="http://www.sap.com/eDocument/Mexico/CFDI/v5"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform" 
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
	xmlns:cfdi="http://www.sat.gob.mx/cfd/4">
	<xsl:output method="xml" version="1.0" encoding="UTF-8"
		indent="yes" />
	<xsl:strip-space elements="*" />
	<xsl:param name="sign" />
	<xsl:param name="certificado"></xsl:param>
 	<xsl:param name="nocertificado"></xsl:param>
 	<xsl:param name="namespace"></xsl:param>


	<!-- keep namespace of root element -->
	<!-- <xsl:template match="/*">
		<xsl:copy>
			<xsl:apply-templates />
		</xsl:copy>
	</xsl:template> -->
  <!--Identity template,  provides default behavior that copies all content into the output -->

  	<xsl:template match="*">
		<xsl:element name="edoc:{local-name()}">
			<xsl:apply-templates select="@* | * | text()" />
		</xsl:element>
	</xsl:template>
	
<!--	<xsl:template match="*">-->
<!--    <xsl:choose>-->
<!--        <xsl:when test="ancestor-or-self::cfdi:Addenda">-->
<!--            <xsl:copy>-->
<!--                <xsl:apply-templates/>-->
<!--            </xsl:copy>-->
<!--        </xsl:when>-->
<!--        <xsl:otherwise>-->
<!--		<xsl:element name="edoc:{local-name()}">-->
<!--			<xsl:apply-templates select="@* | * | text()" />-->
<!--		</xsl:element>-->
<!--        </xsl:otherwise>-->
<!--    </xsl:choose>-->
<!--</xsl:template>-->
	
<xsl:template match="@*">
        <xsl:attribute name="{local-name()}">
            <xsl:value-of select="."/>
        </xsl:attribute>
    </xsl:template>
    
<xsl:template match="/cfdi:Comprobante/cfdi:Addenda" />
  </xsl:stylesheet>